<footer>
    <div class="pull-right">
    Copyright : Sudiksha Enterprises 
    </div>
    <div class="clearfix"></div>
</footer>