<script src="<?php echo base_url ('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url ('assets/js/nicescroll/jquery.nicescroll.min.js'); ?>"></script>
<script src="<?php echo base_url ('assets/js/moment.min2.js'); ?>"></script>
<script src="<?php echo base_url ('assets/js/custom.js'); ?>"></script>
<script src="<?php echo base_url ('assets/js/select/select2.full.js'); ?>"></script>
