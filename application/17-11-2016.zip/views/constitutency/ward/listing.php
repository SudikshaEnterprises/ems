<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>View Ward</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 pull-right  form-group
                     pull-right top_search">
                    <a href="<?php echo base_url ('constitutency/ward/add')
?>"><button class="btn btn-default" type="submit"><i class="fa fa-plus"></i> Add Ward</button></a>
                </div>
            </div>

            <div class="clearfix"></div>


            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Ward's List</h2>

                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sno.</th>
                                        <th>Ward ID</th>
                                        <th>Year</th>
                                        <th>Ward name English</th>
                                        <th>Ward name Hindi</th>
                                        <th>Thana ID</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($ward->num_rows () > 0)
                                    {
                                        ?>
                                    <tbody>
                                        <?php
                                        foreach ($ward->result () as $list)
                                        {
                                            ?>
                                            <tr>
                                                <td><?php echo $list->id;?></td>
                                                <td><?php echo $list->unique_id;?></td>
                                                <td><?php echo $list->year;?></td>
                                                <td><?php echo $list->english_name;?></td>
                                                <td><?php echo $list->hindi_name;?></td>
                                                <td><?php echo $list->thana_unique_id;?></td>
                                                <td>
                                                    <a href="<?php echo site_url ('constitutency/ward/edit/' . $list->id)?>">
                                                        <i class="fa fa-pencil"></i></a>
                                                    <a href="<?php echo site_url ('constitutency/ward/delete/' . $list->id)?>">
                                                        <i class="fa fa-trash-o"></i></a>
                                                </td>
                                            </tr>

                                            <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
