<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>View Ward</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 pull-right  form-group
                pull-right top_search">
                    <a href="<?php echo base_url('constitutency/candidate/add')
                    ?>"><button class="btn btn-default" type="submit"><i class="fa fa-plus"></i> Add Candidate Record</button>
                </div>
            </div>

            <div class="clearfix"></div>


            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Candidate Record's List</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sno.</th>
                                    <th>Record ID</th>
                                    <th>Year</th>
                                    <th>Booth ID</th>
                                    <th>Candidate Name</th>
                                    <th>Party Short Name</th>
                                    <th>Vote Get</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                if ($candidate -> num_rows () > 0)
                                {
                                ?>
                                <tbody>
                                <?php
                                foreach ($candidate -> result () as $list)
                                {
                                    ?>
                                    <tr>
                                        <td style="text-transform:uppercase"><?php echo
                                            $list-> id; ?></td>
                                        <td><?php echo $list -> record_id; ?></td>
                                        <td><?php echo $list -> year; ?></td>
                                        <td><?php echo $list -> booth_id; ?></td>
                                        <td><?php echo $list ->candidate_name; ?></td>
                                        <td><?php echo $list ->party_short_name; ?></td>
                                        <td><?php echo $list ->vote_get; ?></td>


                                        <td>
                                            <a href="<?php echo site_url ('admin/edit/' . $list -> id) ?>">
                                                <i class="fa fa-pencil"></i></a>
                                            <a href="<?php echo site_url ('admin/delete/' . $list -> id) ?>">
                                                <i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>

                                    <?php
                                }
                                }
                                ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
