<!DOCTYPE html>
<html lang="en">
    <?php $this -> load -> view ('includes/login_head'); ?>
    <body class="login">
        <?php echo $content; ?>
    </body>
</html>